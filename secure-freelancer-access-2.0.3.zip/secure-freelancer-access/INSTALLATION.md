# 📦 Инструкция по установке плагина Secure Freelancer Access

## Способ 1: Установка через ZIP-архив (Рекомендуется)

### Шаг 1: Создайте ZIP-архив

Откройте терминал и выполните:

```bash
# Перейдите в папку плагина
cd "/Users/air900/Library/Mobile Documents/com~apple~CloudDocs/08 Code/VS + AI/wp-user-roles-restrict"

# Создайте ZIP-архив (исключая лишние файлы)
zip -r secure-freelancer-access.zip . \
  -x "*.git*" \
  -x "idea.md" \
  -x "test-secure-freelancer-access.php" \
  -x "INSTALLATION.md" \
  -x ".DS_Store"
```

**Результат:** Будет создан файл `secure-freelancer-access.zip`

### Шаг 2: Загрузите в WordPress

1. Откройте админ-панель вашего WordPress сайта
2. Перейдите: **Плагины → Добавить новый**
3. Нажмите кнопку **"Загрузить плагин"** (вверху страницы)
4. Нажмите **"Выберите файл"**
5. Выберите созданный файл `secure-freelancer-access.zip`
6. Нажмите **"Установить сейчас"**

### Шаг 3: Активируйте плагин

После установки:
1. Нажмите кнопку **"Активировать плагин"**
2. Готово! Плагин активирован ✅

---

## Способ 2: Установка через FTP/SSH

### Вариант A: Через SSH (если есть доступ к серверу)

```bash
# 1. Подключитесь к серверу
ssh user@yourserver.com

# 2. Перейдите в папку плагинов WordPress
cd /var/www/html/wp-content/plugins/

# 3. Создайте папку плагина
mkdir secure-freelancer-access

# 4. Выйдите из SSH (Ctrl+D) и скопируйте файлы с локального компьютера
scp -r "/Users/air900/Library/Mobile Documents/com~apple~CloudDocs/08 Code/VS + AI/wp-user-roles-restrict/"* \
  user@yourserver.com:/var/www/html/wp-content/plugins/secure-freelancer-access/

# 5. Снова подключитесь к серверу и установите права
ssh user@yourserver.com
cd /var/www/html/wp-content/plugins/secure-freelancer-access
chmod -R 755 .
chown -R www-data:www-data .  # замените www-data на пользователя веб-сервера
```

### Вариант B: Через FTP (FileZilla, Cyberduck и т.д.)

1. **Откройте FTP-клиент** (например, FileZilla)
2. **Подключитесь к серверу:**
   - Host: `ftp.yoursite.com`
   - Username: ваш FTP-логин
   - Password: ваш FTP-пароль

3. **Перейдите в папку плагинов:**
   - На сервере откройте: `/public_html/wp-content/plugins/`
   - или `/var/www/html/wp-content/plugins/`

4. **Создайте новую папку:**
   - Правая кнопка → "Создать директорию"
   - Имя: `secure-freelancer-access`

5. **Загрузите файлы:**
   - На локальном компьютере откройте папку проекта
   - Выделите все файлы КРОМЕ:
     - `.git/` (папка)
     - `idea.md`
     - `test-secure-freelancer-access.php`
     - `INSTALLATION.md`
   - Перетащите в папку `secure-freelancer-access` на сервере

6. **Активируйте плагин:**
   - Зайдите в админ-панель WordPress
   - Перейдите: **Плагины**
   - Найдите **Secure Freelancer Access**
   - Нажмите **"Активировать"**

---

## Способ 3: Локальная разработка (XAMPP, MAMP, Local by Flywheel)

Если вы работаете на локальном сервере:

```bash
# 1. Найдите папку плагинов WordPress
# XAMPP: /Applications/XAMPP/htdocs/wordpress/wp-content/plugins/
# MAMP: /Applications/MAMP/htdocs/wordpress/wp-content/plugins/
# Local: ~/Local Sites/yoursite/app/public/wp-content/plugins/

# 2. Скопируйте папку плагина
cp -r "/Users/air900/Library/Mobile Documents/com~apple~CloudDocs/08 Code/VS + AI/wp-user-roles-restrict" \
  /Applications/XAMPP/htdocs/wordpress/wp-content/plugins/secure-freelancer-access

# 3. Переименуйте (если нужно)
cd /Applications/XAMPP/htdocs/wordpress/wp-content/plugins/
mv wp-user-roles-restrict secure-freelancer-access

# 4. Откройте WordPress админку и активируйте плагин
```

---

## Способ 4: Через WP-CLI (для продвинутых)

Если на сервере установлен WP-CLI:

```bash
# 1. Перейдите в корень WordPress
cd /var/www/html/wordpress

# 2. Скопируйте плагин
cp -r /путь/к/плагину wp-content/plugins/secure-freelancer-access

# 3. Активируйте через WP-CLI
wp plugin activate secure-freelancer-access

# 4. Проверьте статус
wp plugin list
```

---

## ✅ Проверка установки

После активации плагина:

1. **Проверьте меню админ-панели:**
   - Должен появиться пункт: `Параметры → Ограничение доступа`

2. **Откройте настройки:**
   - Перейдите: `Параметры → Ограничение доступа`
   - Если страница открылась — плагин установлен правильно! ✅

3. **Проверьте ошибки:**
   - Если есть ошибки — включите режим отладки в `wp-config.php`:
   ```php
   define('WP_DEBUG', true);
   define('WP_DEBUG_LOG', true);
   define('WP_DEBUG_DISPLAY', false);
   ```
   - Проверьте файл `/wp-content/debug.log`

---

## 🚀 Быстрый старт после установки

### 1. Создайте тестового редактора (если нет)

```
Админ-панель → Пользователи → Добавить нового
- Имя пользователя: test-editor
- Email: test@example.com
- Роль: Редактор (Editor)
- Пароль: (установите пароль)
```

### 2. Настройте доступ

```
1. Параметры → Ограничение доступа
2. Найдите пользователя "test-editor"
3. Нажмите "Редактировать доступ"
4. Отметьте 2-3 страницы в блоке "Страницы"
5. Нажмите "Сохранить изменения"
```

### 3. Проверьте результат

```
1. Выйдите из админ-панели
2. Войдите как test-editor
3. Откройте: Страницы
4. Результат: Видны только выбранные страницы! ✅
```

---

## 🛠️ Устранение проблем

### Ошибка: "Plugin could not be activated"

**Причина:** PHP версия ниже 7.4

**Решение:**
```bash
# Проверьте версию PHP
php -v

# Обновите PHP до 7.4 или выше
# Для Ubuntu/Debian:
sudo apt-get install php7.4

# Для cPanel: выберите PHP 7.4 в настройках хостинга
```

### Ошибка: "Fatal error: Cannot redeclare class..."

**Причина:** Плагин уже установлен или конфликт имен

**Решение:**
1. Удалите старую версию плагина
2. Убедитесь, что папка называется `secure-freelancer-access`

### Страница "Ограничение доступа" не появилась

**Причина:** Кэш или права доступа

**Решение:**
1. Очистите кэш WordPress (если используете кэширование)
2. Проверьте права пользователя (должен быть Administrator)
3. Деактивируйте и снова активируйте плагин

### Плагин активирован, но не работает

**Причина:** Конфликт с другими плагинами

**Решение:**
1. Отключите все плагины кроме Secure Freelancer Access
2. Проверьте работу
3. Включайте плагины по одному, проверяя каждый

---

## 📋 Требования к серверу

Убедитесь, что сервер соответствует требованиям:

- ✅ WordPress: 5.8 или выше
- ✅ PHP: 7.4 или выше
- ✅ MySQL: 5.6 или выше
- ✅ Права на запись: `wp-content/plugins/`

---

## 📞 Нужна помощь?

1. Проверьте [README.md](README.md) — полная документация
2. Проверьте [readme.txt](readme.txt) — FAQ
3. Включите WP_DEBUG и проверьте логи
4. Создайте тикет с описанием проблемы

---

**Готово!** Теперь вы можете управлять доступом редакторов к страницам и записям! 🎉
